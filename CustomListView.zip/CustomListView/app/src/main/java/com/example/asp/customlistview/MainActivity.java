package com.example.asp.customlistview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    private CustomLisAdapter customLisAdapter;
    private ArrayList<HashMap<String,String>> myLib = new ArrayList<HashMap<String, String>>();
    private ListView mListview;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String[] titles = new String[]{

                "Tere Naina",
                "Hurray"

        };

        String[] desc = new String[]{

                "Tere Naina",
                "Atif Aslam"

        };

        HashMap<String,String> musics = new HashMap<>();

        for(int i =0; i<2 ; i++) {

            musics.put("title",titles[i]);
            musics.put("desc",desc[i]);

            myLib.add(musics);
        }

        mListview = findViewById(R.id.list);

        customLisAdapter = new CustomLisAdapter(this,myLib);

        mListview.setAdapter(customLisAdapter);

        mListview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                String value = mListview.getItemAtPosition(i).toString();
                Toast.makeText(MainActivity.this, value, Toast.LENGTH_SHORT).show();
            }
        });

    }
}
