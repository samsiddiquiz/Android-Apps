package com.example.asp.customlistview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by asp on 2/15/2018.
 */

public class CustomLisAdapter extends BaseAdapter {
    private ArrayList<HashMap<String,String>> mLibrary = new ArrayList<HashMap<String, String>>();
    private Context mContext;
    private LayoutInflater inflater;

    public CustomLisAdapter(Context context,ArrayList<HashMap<String,String>> data) {

        mContext = context;
        mLibrary = data;
        inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return mLibrary.size();
    }

    @Override
    public Object getItem(int i) {
        return i;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {

        View mView = view;

        if(mView == null) {

            mView = inflater.inflate(R.layout.layout_list_items,null);

            TextView title = mView.findViewById(R.id.title);
            TextView desc = mView.findViewById(R.id.desc);
            ImageView image = mView.findViewById(R.id.image);

            HashMap<String,String> map = new HashMap<>();

          map = mLibrary.get(position);

            title.setText(map.get("title"));
            desc.setText(map.get("desc"));
            image.getResources().getDrawable(R.drawable.ic_icon);


        }


        return mView;
    }
}
